<?php
require_once 'Database.php';
$db = Database::getInstance()->getConnection();

// Lấy danh sách Categories cho dropdown filter
$cat_stmt = $db->query("SELECT * FROM categories");
$categories = $cat_stmt->fetchAll();

// Xử lý bộ lọc
$search = $_GET['search'] ?? '';
$cat_id = $_GET['category_id'] ?? '';

// Sử dụng LEFT JOIN để lấy tất cả sản phẩm, kể cả sản phẩm chưa có danh mục (category_id IS NULL)
// Điều này giúp tránh việc sản phẩm bị mất khỏi danh sách khi chưa được phân loại.
$sql = "SELECT p.*, c.category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE p.name LIKE :search";

if ($cat_id != '') {
    $sql .= " AND p.category_id = :cat_id";
}
// Sử dụng Prepared Statements với Placeholders (:search, :cat_id) để chống lỗi SQL Injection.
// Dữ liệu từ người dùng sẽ được bind an toàn trước khi thực thi truy vấn.
$stmt = $db->prepare($sql);
$stmt->bindValue(':search', '%' . $search . '%');
if ($cat_id != '') {
    $stmt->bindValue(':cat_id', $cat_id);
}
$stmt->execute();
$products = $stmt->fetchAll();
?>

<form method="GET">
    <input type="text" name="search" placeholder="Search by name..." value="<?= htmlspecialchars($search) ?>">
    
    <select name="category_id">
        <option value="">All Categories</option>
        <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= $cat_id == $cat['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat['category_name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    
    <button type="submit">Filter</button>
</form>

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Stock</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $p): ?>
            <tr style="<?= $p['stock'] < 10 ? 'background-color: #ffcccc; color: red;' : '' ?>">
                <td><?= $p['id'] ?></td>
                <td><?= htmlspecialchars($p['name']) ?></td>
                <td>$<?= number_format($p['price'], 2) ?></td>
                <td><?= htmlspecialchars($p['category_name'] ?? 'Uncategorized') ?></td>
                <td><?= $p['stock'] ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>